# A Wrinkle in Time — Grade 10 Literature Unit

A four-lesson teaching pack based on Madeleine L’Engle’s *A Wrinkle in Time*.

## Course structure
Each lesson is 90 minutes and covers three chapters:
1. Chapters 1–3 — Belonging, Identity & the Call to Adventure
2. Chapters 4–6 — Darkness, Courage & the Shape of Space
3. Chapters 7–9 — Conformity, Control & the Loss of Self
4. Chapters 10–12 — Love, Courage & the Meaning of Strength

## Files
- `Lesson_1_...pptx` through `Lesson_4_...pptx`: classroom slide decks
- `Vocabulary_Workbook_and_Practice.docx`: vocabulary tables, matching and context practice, teacher key
- `Writing_Prompts_and_Teacher_Guide.docx`: writing prompts, planning organizers, peer review, rubric and lesson rhythm

## Suggested 90-minute flow
- 0–10 min: opening question
- 10–25 min: chapter recap / comprehension
- 25–40 min: vocabulary
- 40–60 min: close reading
- 60–75 min: discussion / debate
- 75–90 min: writing and exit ticket

## GitHub sharing
Create a public repository named `a-wrinkle-in-time-grade10`, upload all files in this folder, and share the repository URL. For a student-friendly landing page, enable GitHub Pages only if you later add a web-based course page; the PPTX and DOCX files can be downloaded directly from the repository.

## Source and classroom use
Chapter summaries, lesson questions, and writing tasks are paraphrased and newly written for instruction. Students should use their own authorized copies of the novel for reading and textual evidence. This repository does not include the novel PDF.
